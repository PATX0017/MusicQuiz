package com.example.Music.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.example.Music.model.Music;
import com.example.Music.service.MusicService;
@RestController
@RequestMapping("/api")


public class MusicController {
	@Autowired
	MusicService MscService;
	
	@RequestMapping(value="/music/track", method=RequestMethod.POST)
	public Music createMusic(@RequestBody Music Msc) {
	    return MscService.createMusic(Msc);
	}
	
	@RequestMapping(value="/music/track", method=RequestMethod.GET)
	public List<Music> readMusic() {
	    return MscService.getMusic();
	}
	
	@RequestMapping(value="/music/track{Id}", method=RequestMethod.PATCH)
	public Music FixMusic (@PathVariable(value="Id") Long id, @RequestBody Music MusicDetails){
	return MscService.fixMusic(id,MusicDetails);}
	
	@RequestMapping(value="/music/{Id}", method=RequestMethod.PUT)
	public Music readMusic(@PathVariable(value = "Id") Long id, @RequestBody Music MusicDetails) {
	    return MscService.updateMusic(id, MusicDetails);
	}

	@RequestMapping(value="/music/{Id}", method=RequestMethod.DELETE)
	public void deleteMusicById(@PathVariable(value = "Id") Long id) {
	    MscService.deleteMusicById(id);
	}

	

}
