package com.example.Music.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.Music.model.Music;
import com.example.Music.repository.MusicRepository;
import java.util.List;
@Service
public class MusicService {


	@Autowired
	MusicRepository MscRepository;

//Create
	public Music createMusic(Music Msc) {
		return MscRepository.save(Msc);
	}

//Read
	public List<Music> getMusic() {
		return MscRepository.findAll();

	}

//Delete
	public void deleteMusicById(Long Id) {
		MscRepository.deleteById(Id);
	}


	

//Update
	// UPDATE
	public Music updateMusic(Long Id, Music MusicDetails) {
	        Music Msc = MscRepository.findById(Id).get();
	        Msc.setName(MusicDetails.getName());
	        Msc.setGenre(MusicDetails.getGenre());
	        Msc.setArtist(MusicDetails.getArtist());
	        Msc.setDurationInSeconds(MusicDetails.getDurationInSeconds());
	        return MscRepository.save(Msc);                                
	}
//Patch
	public Music fixMusic (Long Id, Music MusicDetails) {
	Music Msc = MscRepository.findById(Id).get();
    Msc.setName(MusicDetails.getName());
    Msc.setGenre(MusicDetails.getGenre());
    Msc.setArtist(MusicDetails.getArtist());
    Msc.setDurationInSeconds(MusicDetails.getDurationInSeconds());
    return MscRepository.save(Msc);  
	
	}
	
	
}

